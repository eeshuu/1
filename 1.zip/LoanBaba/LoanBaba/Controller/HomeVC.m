//
//  HomeVC.m
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "HomeVC.h"
#import "CellHome.h"
#import "EMICalVC.h"
#import "LoanVC.h"
#import "EliCal.h"
#import "FAQVC.h"

@interface HomeVC ()
{
    NSMutableArray *arrayMenu;
    BOOL isLoan;
}
@property (weak, nonatomic) IBOutlet UITableView *tblMenu;
@end

@implementation HomeVC

- (void)viewDidLoad {
    [super viewDidLoad];
    isLoan = NO;
    [self callGetCategoryListService:@"0"];
    self.navigationItem.hidesBackButton = YES;
    NSLog(@"User ID %@",[USER_PREF valueForKey:@"RId"]);
    // Do any additional setup after loading the view.
    
    arrayMenu=[[NSMutableArray alloc]init];
    [arrayMenu addObject:@{@"Title":@"EMI Calculator",@"Icon":@"car.png"}];
    [arrayMenu addObject:@{@"Title":@"Eligibility Calculator",@"Icon":@"ico_unsecured_personal_loan.png"}];
    [arrayMenu addObject:@{@"Title":@"Loans",@"Icon":@"ico_unsecured_business_loan.png"}];
    [arrayMenu addObject:@{@"Title":@"About Us",@"Icon":@"home"}];
    [arrayMenu addObject:@{@"Title":@"Blog",@"Icon":@"ico_quick_quote.png"}];
    [_tblMenu setTableFooterView:[[UIView alloc]initWithFrame:CGRectZero]];
    [_tblMenu reloadData];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    UIImageView *imgHeaderOld=(UIImageView *)[self.navigationController.navigationBar viewWithTag:100];
    [imgHeaderOld removeFromSuperview];
    UIImageView *imgHeader=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 124, 20)];
    [imgHeader setImage:[UIImage imageNamed:@"header.png"]];
    [imgHeader setCenter:CGPointMake(self.navigationController.navigationBar.center.x, 22)];
    imgHeader.tag=100;
    [self.navigationController.navigationBar addSubview:imgHeader];
}
#pragma mark - SlideNavigationController Methods -

- (BOOL)slideNavigationControllerShouldDisplayLeftMenu
{
    return YES;
}

- (BOOL)slideNavigationControllerShouldDisplayRightMenu
{
    return NO;
}
#pragma mark-TableView deligate

#pragma mark - UITableView Delegate & Datasrouce -
-(void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove seperator inset
    if ([cell respondsToSelector:@selector(setSeparatorInset:)]) {
        [cell setSeparatorInset:UIEdgeInsetsZero];
    }
    
    // Prevent the cell from inheriting the Table View's margin settings
    if ([cell respondsToSelector:@selector(setPreservesSuperviewLayoutMargins:)]) {
        [cell setPreservesSuperviewLayoutMargins:NO];
    }
    
    // Explictly set your cell's layout margins
    if ([cell respondsToSelector:@selector(setLayoutMargins:)]) {
        [cell setLayoutMargins:UIEdgeInsetsZero];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayMenu count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CellHome *cell = [tableView dequeueReusableCellWithIdentifier:@"CellHome"];
    
    NSMutableDictionary *dictData=[[NSMutableDictionary alloc]initWithDictionary:[arrayMenu objectAtIndex:indexPath.row]];
    /*set*/
    [cell setData:dictData];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    switch (indexPath.row) {
        case 0:{
            
            EMICalVC *VC=[self.storyboard instantiateViewControllerWithIdentifier:@"EMICalVC"];
            VC.isSlide = NO;
            [self.navigationController pushViewController:VC animated:YES];
            
            
        }
            break;
        case 1:{
            EliCal *VC=[self.storyboard instantiateViewControllerWithIdentifier:@"EliCal"];
            VC.isSlide = NO;
            [self.navigationController pushViewController:VC animated:YES];
        }
            break;
        case 2:{
            if ([SharedInstance isNetworkConnected])
            {
                [self callGetCategoryListService:@"0"];
                isLoan = YES;
            }
            else {
                [SharedInstance showAlert:networkNotConnected andTitle:alertTitle];
            }
            
        }
            break;
        case 3:{
            
               
            
        }
            break;
            
        case 4:{
            
        }
            break;
        default:
            break;
    }
    
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


#pragma mark - WebAPIs

- (void)callGetCategoryListService:(NSString *)catId {
    NSString *soapMessage = [NSString stringWithFormat:@"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:tem=\"http://tempuri.org/\">"
                             "<soapenv:Header/>\n"
                             "<soapenv:Body>\n"
                             "<tem:GetCategoryList>\n"
                             "<tem:strParentId>%@</tem:strParentId>\n"
                             "</tem:GetCategoryList>\n"
                             "</soapenv:Body>\n"
                             "</soapenv:Envelope>\n",catId];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
    [SharedInstance callWebServiceFromSoap:soapMessage andSoapAction:GetCategoryList_URL andgetData:^(NSDictionary *data, NSError *error) {
        
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        if (data) {
            NSLog(@"data %@",data);
            
            NSString *responseStr=[[[data objectForKey:@"soap:Body"] objectForKey:@"GetCategoryListResponse"] objectForKey:@"GetCategoryListResult"];
            
            
            NSData* data = [responseStr dataUsingEncoding:NSUTF8StringEncoding];
            NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSMutableArray *arr = [NSMutableArray new];
            
            for (int i = 0; i<values.count; i++) {
                [arr addObject:values[i][0]];
            }
            
            NSLog(@"Data Category %@",arr);
            if (isLoan) {
                isLoan = NO;
                LoanVC *vc = [self.storyboard instantiateViewControllerWithIdentifier:@"LoanVC"];
                vc.arrayMenu = [NSMutableArray arrayWithArray:arr];
                [self.navigationController pushViewController:vc animated:YES];
            }
            else {
                /*
                 contents=@[@[@[@"Home"],
                 @[@"Services", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property", @"Unsecured Business Loan", @"Lease Rental Discounting"],
                 @[@"About us"],@[@"Contact"],@[@"FAQ", @"Car Loan", @"Unsecured Personal Loan", @"Unsecured Business Loan", @"Home Loan", @"loan Against Property",@"Lease Rental Discounting"],@[@"Track Application"],@[@"Finance Tools", @"EMI Calculator", @"Eligibility Calculator"],@[@"Blog"]]];
                 */
                NSMutableArray *arrServices = [NSMutableArray new];
                [arrServices addObject:@"Services"];
                NSMutableArray *arrFAQ = [NSMutableArray new];
                [arrFAQ addObject:@"FAQ"];
                for(NSDictionary *rr in arr) {
                    [arrServices addObject:rr[@"CategoryName"]];
                    [arrFAQ addObject:rr[@"CategoryName"]];
                }
                
                NSArray *content=@[@[@[@"Home"],
                                                arrServices,
                                                @[@"About us"],@[@"Contact"],arrFAQ,@[@"Track Application"],@[@"Finance Tools", @"EMI Calculator", @"Eligibility Calculator"],@[@"Blog"]]];
                ((AppDelegate*)[UIApplication sharedApplication].delegate).arrContent = [NSMutableArray arrayWithArray:content];
                ((AppDelegate*)[UIApplication sharedApplication].delegate).arrCat = [NSMutableArray arrayWithArray:arr];
                
            }
            
            
        }
        else {
            [SharedInstance showAlert:error.description andTitle:alertTitle];
        }
        
    }];
}
@end

//
//  QuestionVC.m
//  LoanBaba
//
//  Created by Dheerendra chaturvedi on 22/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "QuestionVC.h"

@interface QuestionVC ()
{
    AppDelegate *appDelegate;
}
@property (weak, nonatomic) IBOutlet UIButton *btnPrevious;
@property (weak, nonatomic) IBOutlet UIButton *btnNext;
@property (weak, nonatomic) IBOutlet UIPageControl *pageController;

@end

@implementation QuestionVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.title=@"Question's";
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    [_pageController setNumberOfPages:[appDelegate.arrayQuestion count]];
    if (appDelegate.intQesCount == 0) {
        [self.btnPrevious setEnabled:NO];
        [self.btnPrevious setAlpha:.6];
    }
    else{
        [self.btnPrevious setEnabled:YES];
        [self.btnPrevious setAlpha:1];
    }
    
    [_pageController setCurrentPage:appDelegate.intQesCount];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (appDelegate.intQesCount == 0) {
        [self.navigationItem setHidesBackButton:NO];
    }
    else{
        [self.navigationItem setHidesBackButton:YES];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)btnNext:(id)sender {
    NSLog(@"%@",[appDelegate.arrayQuestion objectAtIndex:appDelegate.intQesCount]);
    appDelegate.intQesCount++;
    QuestionVC *vc=[self.storyboard instantiateViewControllerWithIdentifier:@"QuestionVC"];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)btnPrevious:(id)sender {
    appDelegate.intQesCount--;
    [self.navigationController popViewControllerAnimated:YES];
}


@end

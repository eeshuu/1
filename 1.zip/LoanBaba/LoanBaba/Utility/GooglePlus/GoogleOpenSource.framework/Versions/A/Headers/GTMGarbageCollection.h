//
// This file previously included utility functions for working
// with Garbage Collection on Mac OS X.
//

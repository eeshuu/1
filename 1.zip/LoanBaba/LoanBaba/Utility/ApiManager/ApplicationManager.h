//
//  ApplicationManager.h
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

typedef void (^StringConsumer)(NSDictionary* , NSError *);

@interface ApplicationManager : NSObject

+ (id)sharedManagerInstance;

- (BOOL)isNetworkConnected;
- (BOOL)emailAddressIsValid:(NSString *)emailAddress;

- (void)showAlert:(NSString *)message andTitle:(NSString *)title;

- (void)callWebServiceFromSoap:(NSString *)soapMessage andSoapAction:(NSString *)soapAction andgetData:(StringConsumer) consumer;
@end

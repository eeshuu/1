//
//  ApplicationManager.m
//  LoanBaba
//
//  Created by Nilesh Pal on 14/09/15.
//  Copyright (c) 2015 Nilesh Pal. All rights reserved.
//

#import "ApplicationManager.h"
#import "Constant.h"
#import "Reachability.h"

@implementation ApplicationManager

+ (id)sharedManagerInstance {
    
    static ApplicationManager *sharedManager = nil;
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedManager = [[self alloc] init];
    });
    
    return sharedManager;
}

#pragma mark - Validation Methods

- (BOOL)isNetworkConnected {
    
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus networkStatus = [reachability currentReachabilityStatus];
    return networkStatus != NotReachable;
}

- (BOOL)emailAddressIsValid:(NSString *)emailAddress {
    
    NSString *emailRegex =
    @"(?:[a-z0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[a-z0-9!#$%\\&'*+/=?\\^_`{|}"
    @"~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\"
    @"x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-"
    @"z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5"
    @"]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-"
    @"9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21"
    @"-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES[c] %@", emailRegex];
    
    return [emailTest evaluateWithObject:emailAddress];
}


#pragma mark - Show Alert

-(void)showAlert:(NSString *)message andTitle:(NSString *)title {
    
    [[[UIAlertView alloc]initWithTitle:title message:message delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil]show];
}

#pragma mark - Web Api

- (void)callWebServiceFromSoap:(NSString *)soapMessage andSoapAction:(NSString *)soapAction andgetData:(StringConsumer) consumer
{
    
    NSLog(@"Soap = %@\nAction = %@",soapMessage,soapAction);
    
    NSURL *url = [NSURL URLWithString:@"http://momentumads.net/loanbabaweb/appservice.asmx"];
    NSMutableURLRequest *theRequest = [NSMutableURLRequest requestWithURL:url];
    NSString *msgLength = [NSString stringWithFormat:@"%lu", (unsigned long)[soapMessage length]];
    
    [theRequest addValue: @"text/xml; charset=utf-8" forHTTPHeaderField:@"Content-Type"];
    [theRequest addValue: soapAction forHTTPHeaderField:@"SOAPAction"];
    [theRequest addValue: msgLength forHTTPHeaderField:@"Content-Length"];
    [theRequest setHTTPMethod:@"POST"];
    [theRequest setHTTPBody: [soapMessage dataUsingEncoding:NSUTF8StringEncoding]];
    
    
    [NSURLConnection sendAsynchronousRequest:theRequest queue:[NSOperationQueue mainQueue]  completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        
        if ([(NSHTTPURLResponse *)response statusCode]==200)
        {
            NSMutableData *data123=[NSMutableData dataWithData:data];
            NSString *theXML = [[NSString alloc] initWithBytes: [data123 mutableBytes] length:[data length] encoding:NSUTF8StringEncoding];
            NSDictionary *xmlDoc = [NSDictionary dictionaryWithXMLString:theXML];
            consumer(xmlDoc,nil);
        }
        else
        {
            consumer(nil,error);
        }
    }];
}
@end
